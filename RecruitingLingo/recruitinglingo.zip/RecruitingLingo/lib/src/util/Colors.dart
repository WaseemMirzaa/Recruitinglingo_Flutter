
import 'package:flutter/material.dart';

const Color appColor = Color(0xffc40c0c);
const Color shapeColor =  Color(0xffE0E0E0);
const Color borderColor = Colors.white;