package com.developlogix.recruitinglingo.recruitinglingo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
